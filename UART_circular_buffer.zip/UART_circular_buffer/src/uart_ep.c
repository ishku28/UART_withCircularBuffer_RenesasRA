/***********************************************************************************************************************
 * File Name    : uart.c
 * Description  : Contains UART functions definition using interrupts.
 **********************************************************************************************************************/
/***********************************************************************************************************************
* Copyright (c) 2020 - 2024 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/

#include "common_utils.h"
#include "uart_ep.h"

/* Constants */
#define CIRCULAR_BUFFER_SIZE 4  // Define the size of the circular buffer

/* Global variables */
volatile uint8_t g_uart_event = RESET_VALUE;
volatile uint8_t circular_buffer[CIRCULAR_BUFFER_SIZE];
volatile int head = 0;  // Points to the next position to write
volatile int tail = 0;  // Points to the next position to read

/*****************************************************************************************************************
 *  @brief       UART Example project to demonstrate the functionality
 *  @param[in]   None
 *  @retval      FSP_SUCCESS     Upon success
 *  @retval      Any Other Error code apart from FSP_SUCCESS
 ****************************************************************************************************************/
fsp_err_t uart_ep_demo(void)
{
    fsp_err_t err = FSP_SUCCESS;

    /* Initialize UART */
    err = uart_initialize();
    if (FSP_SUCCESS != err)
    {
        APP_ERR_PRINT("\r\n** UART Initialization Failed **\r\n");
        return err;
    }

    while (true)
    {
        /* Main loop can perform other tasks or enter low power mode */
        __WFI();  // Wait For Interrupt

        /* Process data from the circular buffer */
        read_from_circular_buffer();
    }
}

/*******************************************************************************************************************
 * @brief       Initialize UART and enable interrupts.
 * @param[in]   None
 * @retval      FSP_SUCCESS         Upon successful open
 * @retval      Any Other Error code apart from FSP_SUCCESS  Unsuccessful open
 *******************************************************************************************************************/
fsp_err_t uart_initialize(void)
{
    fsp_err_t err = FSP_SUCCESS;

    /* Initialize UART channel with baud rate 115200 */
#if defined (BOARD_RA6T2_MCK)
    err = R_SCI_B_UART_Open(&g_uart9_ctrl, &g_uart9_cfg);
#else
    err = R_SCI_UART_Open(&g_uart9_ctrl, &g_uart9_cfg);
#endif
    if (FSP_SUCCESS != err)
    {
        APP_ERR_PRINT("\r\n** R_SCI_UART_Open API failed **\r\n");
        return err;
    }

    return err;
}

/*****************************************************************************************************************
 *  @brief       Print user message to terminal
 *  @param[in]   p_msg
 *  @retval      FSP_SUCCESS                Upon success
 *  @retval      Any Other Error code apart from FSP_SUCCESS,  Unsuccessful write operation
 ****************************************************************************************************************/
fsp_err_t uart_print_user_msg(uint8_t *p_msg)
{
    fsp_err_t err = FSP_SUCCESS;
    uint8_t msg_len = 1; // Only one character is sent at a time

    /* Writing to terminal */
#if defined (BOARD_RA6T2_MCK)
    err = R_SCI_B_UART_Write(&g_uart9_ctrl, p_msg, msg_len);
#else
    err = R_SCI_UART_Write(&g_uart9_ctrl, p_msg, msg_len);
#endif

    if (FSP_SUCCESS != err)
    {
        APP_ERR_PRINT("\r\n** R_SCI_UART_Write API Failed **\r\n");
    }

    return err;
}

/*****************************************************************************************************************
 *  @brief      UART user callback
 *  @param[in]  p_args
 *  @retval     None
 ****************************************************************************************************************/
void user_uart_callback(uart_callback_args_t *p_args)
{
    if (UART_EVENT_RX_CHAR == p_args->event)
    {
        /* Store the received character in the circular buffer */
        circular_buffer[head] = (uint8_t)p_args->data;
        head = (head + 1) % CIRCULAR_BUFFER_SIZE;

        /* Check for buffer overflow */
        if (head == tail)
        {
            // Buffer overflow, handle it (e.g., discard oldest data)
            tail = (tail + 1) % CIRCULAR_BUFFER_SIZE;
        }

        /* Echo back the received character */
        uart_print_user_msg((uint8_t *)&p_args->data);
    }
    else if (UART_EVENT_TX_COMPLETE == p_args->event)
    {
        /* Transmission complete event */
        g_uart_event = UART_EVENT_TX_COMPLETE;
    }
    else if (UART_ERROR_EVENTS == p_args->event)
    {
        APP_ERR_PRINT("\r\n** UART Error Event Received **\r\n");
    }
}

/*****************************************************************************************************************
 *  @brief      Read data from the circular buffer
 *  @param[in]  None
 *  @retval     None
 ****************************************************************************************************************/
void read_from_circular_buffer(void)
{
    while (tail != head)
    {
        circular_buffer[tail];
        tail = (tail + 1) % CIRCULAR_BUFFER_SIZE;
    }
}
