/***********************************************************************************************************************
 * File Name    : uart_ep.h
 * Description  : Contains function declarations and macros for uart_ep.c.
 **********************************************************************************************************************/
/***********************************************************************************************************************
* Copyright (c) 2020 - 2024 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/

#ifndef UART_EP_H_
#define UART_EP_H_

#include "bsp_api.h"  // Include necessary headers for FSP types

/* Macro definitions */
#define CARRIAGE_ASCII            (13u)     /* Carriage return */
#define ZERO_ASCII                (48u)     /* ASCII value of zero */
#define NINE_ASCII                (57u)     /* ASCII value for nine */
#define DATA_LENGTH               (4u)      /* Expected Input Data length */
#define UART_ERROR_EVENTS         (UART_EVENT_BREAK_DETECT | UART_EVENT_ERR_OVERFLOW | \
                                   UART_EVENT_ERR_FRAMING | UART_EVENT_ERR_PARITY)  /* UART Error event bits */

/* Function declarations */
fsp_err_t uart_ep_demo(void);
fsp_err_t uart_print_user_msg(uint8_t *p_msg);
void uart_read_data(void);  // Adjusted to match the implementation
fsp_err_t uart_initialize(void);
void process_received_data(uint8_t *p_data, uint8_t length);  // Added to match the implementation
void read_from_circular_buffer(void);

/* External variable declarations */
extern volatile uint8_t g_temp_buffer[DATA_LENGTH];
extern volatile uint8_t g_counter_var;
extern volatile uint8_t g_uart_event;

#endif /* UART_EP_H_ */
