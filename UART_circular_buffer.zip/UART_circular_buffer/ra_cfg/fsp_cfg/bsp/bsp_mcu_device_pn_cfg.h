/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FA6T2BD3CFP
#define BSP_MCU_FEATURE_SET ('B')
#define BSP_ROM_SIZE_BYTES (524288)
#define BSP_RAM_SIZE_BYTES (65536)
#define BSP_DATA_FLASH_SIZE_BYTES (16384)
#define BSP_PACKAGE_LQFP
#define BSP_PACKAGE_PINS (100)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
